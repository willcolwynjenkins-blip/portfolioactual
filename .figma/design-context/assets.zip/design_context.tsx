const assetPathPrefix = "./assets";
const imgImage10 = `${assetPathPrefix}/e1d9e.png`;
const img8921247912A370D197K2 = `${assetPathPrefix}/b8e89.png`;
const imgImage20 = `${assetPathPrefix}/19a14.png`;
const imgImage17 = `${assetPathPrefix}/e48a4.png`;
const img3441056553Df03Eae0E1B2 = `${assetPathPrefix}/f7750.png`;
const imgImage22 = `${assetPathPrefix}/03836.png`;

export default function Desktop1() {
  return (
    <div className="bg-white relative size-full" data-node-id="1:2" data-name="Desktop - 1">
      <div className="absolute contents left-0 top-0" data-node-id="1:3">
        <div className="absolute h-[892px] left-0 top-0 w-[1440px]" data-node-id="1:4" data-name="image 10">
          <img alt="" className="absolute block inset-0 max-w-none size-full" height="892" src={imgImage10} width="1440" />
        </div>
      </div>
      <div className="absolute h-[1156px] left-0 top-[892px] w-[1440px]" data-node-id="1:5" data-name="89212479_12a370d197_k 2">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img8921247912A370D197K2} />
      </div>
      <div className="absolute h-[569px] left-0 top-[2502px] w-[741px]" data-node-id="1:6" data-name="image 20">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage20} />
      </div>
      <div className="absolute h-[1024px] left-[741px] top-[2048px] w-[699px]" data-node-id="1:7" data-name="image 17">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage17} />
      </div>
      <div className="absolute h-[454px] left-0 top-[2048px] w-[741px]" data-node-id="1:8" data-name="3441056553_df03eae0e1_b 2">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img3441056553Df03Eae0E1B2} />
      </div>
      <div className="absolute h-[1024px] left-0 top-[3070px] w-[1440px]" data-node-id="1:9" data-name="image 22">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage22} />
      </div>
      <div className="-translate-x-1/2 [word-break:break-word] absolute bg-[#ffeb84] bg-clip-text font-['Helvetica_Neue:Regular'] h-[41px] leading-[0] left-[719.5px] not-italic text-[30px] text-[transparent] text-center top-[381px] tracking-[-2.4px] w-[405px]" data-node-id="1:10">
        <p className="leading-[1.2] mb-0">Will Colwyn</p>
        <p className="leading-[1.2] mb-0">2026 September 28</p>
        <p className="leading-[1.2] mb-0">10:30 AM</p>
        <p className="leading-[1.2]">​</p>
      </div>
    </div>
  );
}